[FR]
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
[+] Saturne est un outil OSINT complet développé en batch.
[+] Il regroupe des fonctionnalités variées telles que la recherche de pseudonymes, le scan d'IP, l'analyse de site web, l'extraction de métadonnées et bien plus encore.
[+] Ce projet est open-source et peut être étudié à des fins éducatives et techniques.
[+] Toute tentative de modification du code est fortement déconseillée sans autorisation.
[+] Chaque ligne du script a été conçue avec précision pour assurer une stabilité optimale.
[+] L’outil est en constante évolution, avec de nouvelles fonctionnalités régulièrement ajoutées.
[+] Ce projet a été développé par Ehqie, passionné de cybersécurité et d’OSINT.
[+] Aucune garantie n’est fournie concernant les résultats obtenus via les services externes utilisés.
[+] Saturne ne doit pas être utilisé à des fins illégales, malveillantes ou intrusives.
[+] En utilisant cet outil, vous acceptez de l’utiliser de manière éthique et responsable.
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
[EN]
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
[+] Saturne is a complete OSINT tool developed in batch scripting.
[+] It includes multiple features such as username searches, IP scanning, website analysis, metadata extraction, and much more.
[+] This project is open-source and may be studied for educational and technical purposes.
[+] Any attempt to modify the code is strongly discouraged without proper authorization.
[+] Every line in the script has been written with precision to ensure maximum stability.
[+] The tool is under active development, with new features regularly being added.
[+] This project was developed by Ehqie, an enthusiast in cybersecurity and OSINT.
[+] No guarantee is provided regarding the accuracy of the data retrieved from external services.
[+] Saturne must not be used for illegal, malicious, or intrusive purposes.
[+] By using this tool, you agree to use it ethically and responsibly.
